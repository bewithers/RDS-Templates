# 
# Until the Rhapsody team  cleans up their installer to fix the "blocked" .exe, run othis command
# as Administrator in a PowerShell window on each VDI machine.
# 1/10/2019 B. Edward Withers / RedRock
#
foreach ($folder in (Get-ChildItem c:\users -Directory)) { 
    Get-ChildItem -recurse "$($folder.fullname)\AppData" -include ALC.Rhapsody.MainUI.Views.exe |
    Unblock-File -Verbose
}
