﻿$machines=
    "wvdc1-0",
    "wvdc1-1",
    "wvdc1-2",
    "wvde1-0",
    "wvde1-1",
    "wvde1-2"

$sb = {
        write-output Machine: $env:COMPUTERNAME
        gwmi win32_logicaldisk | 
            ft deviceid,
                @{l="Free";e={"{0:f2}" -f ([long]$_.Freespace/1GB)}},
                @{l="Total";e={"{0:f2}" -f ([long]$_.Size/1GB)}}
        }

foreach ($m in $machines){
    invoke-command -ComputerName $m -ScriptBlock $sb
}