﻿############################################################
<#
.Synopsis
        This script runs at login create a Dropbox icon on the user's desktop.

.Description
        This script runs at login, looks for the DropBox shortcut
        on the user's desktop and creates it if it does not exit

.Notes
        NAME:    Install-DropboxAtLogin
        AUTHOR:  B. Edward Withers / Red Rock Technology Solutions
        CREATED: 08/23/2019

        Most of the original (commented out) script was copied from
        https://forum.pulseway.com/topic/1937-install-dropbox-with-powershell/
        with only minor changes by me. (Confirm download location, etc.)

        MODIFIED: 9/3/2019
        Turns out Dropbox install REQUIRES admin priv, so replaced that with
        creating a shortcut to the web interfaces on the user's desktop.
#>
############################################################
#Requires -Version 5.0

$ShortcutPath = ($env:USERPROFILE + "\Desktop\Dropbox.url")
if(-not (Test-Path $ShortcutPath)){
    $Shell = New-Object -ComObject ("WScript.Shell")
    $Favorite = $Shell.CreateShortcut($ShortcutPath)
    $Favorite.TargetPath = "https://www.dropbox.com/";
    $Favorite.Save()
}

<#
9/3/2019 BEW Commented out original code.

# Path for the workdir
$workdir = "$($env:USERPROFILE)\Downloads\DropBox"

# See if Dropbox has already been installed and cleanup if it has
if(Test-Path "$($env:LOCALAPPDATA)\Dropbox"){
    if (Test-Path $workdir){
        # Remove the installer
        Remove-Item -Force $workdir\dropbox*
        Remove-Item -Force $workdir
    }
}
else{
# Otherwise download and install

    # Silently Install Dropbox 
    # Download URL: https://www.dropbox.com/downloading?full=1&os=win

    # Check if work directory exists if not create it

    If (Test-Path -Path $workdir -PathType Container)
    { Write-Host "$workdir already exists" -ForegroundColor Red}
    ELSE
    { New-Item -Path $workdir  -ItemType directory }

    # Download the installer

    # BEW - This url is slightly different than the one listed above
    #     (which matches what I got by visiting the site in a browser)
    #     but this url actually downloads the file where the first one
    #     only gets the download page.  (This url appears to be the
    #     "restart download" link.)
    $source = "https://www.dropbox.com/download?full=1&plat=win"
    $destination = "$workdir\dropbox.exe"
    Invoke-WebRequest $source -OutFile $destination

    # Start the installation

    Start-Process -FilePath "$workdir\dropbox.exe" -ArgumentList "/S"
} # End of test for DropBox installed or not

End of commented out original code
#>