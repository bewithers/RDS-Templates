﻿############################################################
<#
.Synopsis
        This script runs at login to install Rhapsody if it is missing

.Description
        This script runs at login, looks for the Rhapsody executable
        in its normal location and if it does not find it, invokes the
        installer from the Start Menu location.

        Created at the request of Branden Seeberger
        https://secure.helpscout.net/conversation/931386145/1499079/?folderId=755661

.Notes
        NAME:    Install-RhapsodyAtLogin
        AUTHOR:  B. Edward Withers / Red Rock Technology Solutions
        CREATED: 08/23/2019

        8/28/2019 B. Edward Withers / Red Rock Technology Solutions
            Replaced hard-coded path with path based on env:LOCALAPPDATA.
#>
############################################################
#Requires -Version 2.0

$RhapsodyInstalled = $false
if (Test-Path "$($env:LOCALAPPDATA)\Apps\2.0\"){
    if (dir "$($env:LOCALAPPDATA)\Apps\2.0\" -recurse | 
            ?{$_.name -like "ALC.Rhapsody.MainUI.Views.exe"}) {
            $RhapsodyInstalled = $true
    }
}
if (-not $RhapsodyInstalled){
    Read-Host -Prompt "We see that you do not have Rhapsody installed on this VDI machine.  Please hit Enter and the installation will begin."
    Invoke-item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\ALC Schools\Rhapsody.url"
}

